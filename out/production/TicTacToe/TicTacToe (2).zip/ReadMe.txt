--------------------TicTacToe-------------------

Required functionalities 
	Choose mode 
		player can play a local game against a friend on one computer with only one user interface.
	Game Rule
		Only one player at a time can mark squares.
		If player x / player o wins than it popup dialouge box saying player x / player o wins or 
		if both player wins than it popup saying Draw.
		If the game is over than user can play it again or exit the game.

Optional functionalities 
	Variable Board Size
		Players can choose the board size on the starting of the game as they desire. 

Bug :- When user choose the board size greater than 5x5, the bussiness logic is working fine 
       but UI is not working properly.

	
		