public enum GameStatus {
    Incomplete,Xwins,Owins,Tie
}
